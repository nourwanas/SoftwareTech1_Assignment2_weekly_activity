from PIL import Image

# importing an image
image = Image.open("Assets/Insects/2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG")
image.show()

# getting basic image info
print(image.size)
print(image.filename)
print(image.format)

#flipping the image

#image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
#image = image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
#image.show()

#rotating the image
image = image.transpose(Image.Transpose.ROTATE_90)
image.show()

#exercise
image_rotated = image.rotate(30)
image_rotated.save("Assets/Insects/image_rotated.png", "PNG")